package enquete

class EnqueteController {

    def scaffold = true
}
