package agenda

class ContatoController {

    def scaffold = true
}
