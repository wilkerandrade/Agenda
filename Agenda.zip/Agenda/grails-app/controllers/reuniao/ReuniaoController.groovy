package reuniao

class ReuniaoController {

    def scaffold = true
}
