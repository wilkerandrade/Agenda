package enquete

class Enquete {

    String pergunta
    String alternativaA
    String alternativaB
    String alternativaC
    String alternativaD
    String alternativaE
    String correta
    
    static hasMany = [contato: String]
    static constraints = {
        
        
    }
}
