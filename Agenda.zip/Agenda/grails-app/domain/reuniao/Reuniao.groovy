package reuniao

import agenda.Contato

class Reuniao {
    String ata
    Date data
    
    
    static hasMany = [contatos:Contato]
     def contato = new Contato()
    
    static constraints = {
    }
}
